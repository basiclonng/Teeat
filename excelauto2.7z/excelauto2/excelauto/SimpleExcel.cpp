// SimpleExcel.cpp: implementation of the SimpleExcel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "excelauto.h"
#include "SimpleExcel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
namespace XEXCEL
{


SimpleExcel::SimpleExcel()
{
	AfxOleInit();
	vtOptional=COleVariant((long)DISP_E_PARAMNOTFOUND, VT_ERROR);
	vTrue=COleVariant((short)TRUE);
	vFalse=COleVariant ((short)FALSE);
}

SimpleExcel::~SimpleExcel()
{
	excelapp.ReleaseDispatch();
	worksheets.ReleaseDispatch();
	workbooks.ReleaseDispatch();
	worksheet.ReleaseDispatch();
	workbook.ReleaseDispatch();
	range.ReleaseDispatch();
}

BOOL SimpleExcel::CreateApp()
{
	BOOL hr=excelapp.CreateDispatch(_T("Excel.Application"));
	if (!hr)
	{
		MessageBox(NULL,"Can't create excel ","ERROR",MB_OK);
		return FALSE;
	}
	return TRUE;

}

void SimpleExcel::CreateWorkbook()
{
	workbooks=excelapp.GetWorkbooks();
	workbook=workbooks.Add(vtOptional);
	worksheets=workbook.GetWorksheets();
	worksheet=worksheets.GetItem(COleVariant(long(1)));
}

void SimpleExcel::Show(BOOL bNewValue)
{
	excelapp.SetVisible(bNewValue);
}

void SimpleExcel::SetCellString(long irow, long icol, LPCTSTR value)
{
	range.AttachDispatch(worksheet.GetCells(),true);
	range.SetItem(COleVariant(irow),COleVariant(icol),COleVariant(value));
}

void SimpleExcel::SetSheetCellString(long isheet, long irow, long icol, LPCTSTR value)
{
	worksheet=worksheets.GetItem(COleVariant(isheet));
	worksheet.Activate();
	range.AttachDispatch(worksheet.GetCells(),true);
	range.SetItem(COleVariant(irow),COleVariant(icol),COleVariant(value));
	
}

void SimpleExcel::SaveAs(LPCTSTR name)
{
	workbook.SaveAs(COleVariant(name),vtOptional,
		vtOptional,vtOptional,
		vtOptional,vtOptional,(long)0,vtOptional,vtOptional,vtOptional,
		vtOptional,vtOptional);

	

}

void SimpleExcel::CloseApp()
{
	excelapp.Quit();

}

void SimpleExcel::CloseAppSave(LPCTSTR name)
{
	workbook.SaveAs(COleVariant(name),vtOptional,
		vtOptional,vtOptional,
		vtOptional,vtOptional,(long)0,vtOptional,vtOptional,vtOptional,
		vtOptional,vtOptional);
}

void SimpleExcel::CreateExcel()
{

	CreateApp();
	CreateWorkbook();
}

void SimpleExcel::ReleaseControl()
{
	excelapp.SetUserControl(TRUE);
}

void SimpleExcel::Open(LPCTSTR name)
{
	workbooks=excelapp.GetWorkbooks();
	workbook=workbooks.Open(name,vtOptional,vtOptional,vtOptional, vtOptional, vtOptional, vtOptional,
        vtOptional, vtOptional, vtOptional, vtOptional,
        vtOptional, vtOptional, vtOptional, vtOptional);
	worksheets=workbook.GetWorksheets();
	worksheet=worksheets.GetItem(COleVariant(long(1)));
}

void SimpleExcel::SetCellValue(long irow, long icol, VARIANT &vt)
{
	range.AttachDispatch(worksheet.GetCells(),true);
	range.SetItem(COleVariant(irow),COleVariant(icol),COleVariant(vt));	
}

void SimpleExcel::MakeAutoFit()
{
	cols=range.GetEntireColumn();
	cols.AutoFit();
}

void SimpleExcel::Save()
{
	workbook.Save();

}

void SimpleExcel::CloseWorkbook()
{
	workbook.Close(vFalse,COleVariant(""),vtOptional);
}

void SimpleExcel::SetSheetCellValue(long isheet, long irow, long icol, VARIANT &vt)
{
	worksheet=worksheets.GetItem(COleVariant(isheet));
	worksheet.Activate();
	range.AttachDispatch(worksheet.GetCells(),true);
	range.SetItem(COleVariant(irow),COleVariant(icol),COleVariant(vt));
		
}

void SimpleExcel::SheetSelect(long isheet)
{
	worksheets=workbook.GetWorksheets();
	worksheet=worksheets.GetItem(COleVariant(long(isheet)));
	worksheet.Activate();

}

void SimpleExcel::MergeCell(long irows, long icols,long  irowe,long  icole)
{
	//�������ʱӦ��ע�⣺
	//��һ���͵ڶ��������ֱ������Ͻǵĵ�Ԫ��������У�
	//�ڶ����͵����������ֱ������½ǵĵ�Ԫ��������С�
	// todo:��һ�δ�����͵�����֤���õ�˳��

	Range unionRange;
	unionRange.AttachDispatch(range.GetItem (COleVariant((long)irows),COleVariant((long)icols)).pdispVal );
	unionRange.AttachDispatch(unionRange.GetResize(COleVariant((long)(irowe-irows+1)),COleVariant((long)(icole-icols+1))));
	unionRange.Merge(COleVariant((long)0));   //�ϲ���Ԫ��

	unionRange.ReleaseDispatch();

}

void SimpleExcel::SetCellColor(long irow,long icol,COLORREF color)
{
	Font font;
	Range r;
	range.AttachDispatch(worksheet.GetCells());
	r.AttachDispatch((range.GetItem (COleVariant(long(irow)), COleVariant(long(icol)))).pdispVal);
	font=r.GetFont();
	font.SetColor(COleVariant((long)color));  
	font.ReleaseDispatch();
	r.ReleaseDispatch();

}

void SimpleExcel::AddSheet()
{
	worksheets=workbook.GetWorksheets();
	_Worksheet tmp=	worksheets.GetItem(COleVariant((long)worksheets.GetCount()));

	VARIANT var;
	var.vt = VT_DISPATCH;
	var.pdispVal = tmp;

	worksheet=worksheets.Add(vtOptional,var,COleVariant(long(1)),vtOptional);

	tmp.ReleaseDispatch();

// 	worksheet.Select(vTrue);
// 	
// 	worksheet.Move(vtOptional,var);
}

void SimpleExcel::AddSheet(long count)
{
	worksheets=workbook.GetWorksheets();

	_Worksheet tmp=	worksheets.GetItem(COleVariant((long)worksheets.GetCount()));
	
	VARIANT var;
	var.vt = VT_DISPATCH;
	var.pdispVal = tmp;

	worksheet=worksheets.Add(vtOptional,var,COleVariant(count),vtOptional);

	tmp.ReleaseDispatch();

}

void SimpleExcel::SetSheetName(long sheet, LPCTSTR sheetname)
{
	worksheets=workbook.GetWorksheets();
	worksheet=worksheets.GetItem(COleVariant(long(sheet)));
	worksheet.Activate();
	worksheet.SetName(sheetname);

}

void SimpleExcel::InsertSheeta(long after)
{

	if ((after<1)||(after>(long)worksheets.GetCount()))
	{
		return ;
	}
	worksheets=workbook.GetWorksheets();
	
	_Worksheet tmp=	worksheets.GetItem(COleVariant(after));
	
	VARIANT var;
	var.vt = VT_DISPATCH;
	var.pdispVal = tmp;
	
	worksheet=worksheets.Add(vtOptional,var,COleVariant(long(1)),vtOptional);

	tmp.ReleaseDispatch();

}

void SimpleExcel::MoveSheeta(long iafter,long isheet)
{
	if ((iafter==0)||(iafter>(long)worksheets.GetCount()))
	{
		return ;
	}

	if ((isheet<1)||(isheet>(long)worksheets.GetCount()))
	{
		return ;
	}
	worksheets=workbook.GetWorksheets();
	
	worksheet= worksheets.GetItem(COleVariant(isheet));

	worksheets=workbook.GetWorksheets();



	_Worksheet tmp=	worksheets.GetItem(COleVariant(iafter));

	VARIANT vara;
	vara.vt = VT_DISPATCH;
	vara.pdispVal = tmp;




	worksheet.Move(vtOptional,vara);

	tmp.ReleaseDispatch();

}

void SimpleExcel::MoveSheetb(long ibefore,long isheet)
{
	if ((ibefore==0)||(ibefore>(long)worksheets.GetCount()))
	{
		return ;
	}
	
	if ((isheet<1)||(isheet>(long)worksheets.GetCount()))
	{
		return ;
	}
	worksheets=workbook.GetWorksheets();
	
	worksheet= worksheets.GetItem(COleVariant(isheet));
	
	worksheets=workbook.GetWorksheets();
	
	
	
	_Worksheet tmp=	worksheets.GetItem(COleVariant(ibefore));
	
	VARIANT varb;
	varb.vt = VT_DISPATCH;
	varb.pdispVal = tmp;
	
	
	
	
	worksheet.Move(varb,vtOptional);

	tmp.ReleaseDispatch();
}

void SimpleExcel::InsertSheetb(long ibefore)
{
	if ((ibefore<1)||(ibefore>(long)worksheets.GetCount()))
	{
		return ;
	}
	worksheets=workbook.GetWorksheets();
	
	_Worksheet tmp=	worksheets.GetItem(COleVariant(ibefore));
	
	VARIANT var;
	var.vt = VT_DISPATCH;
	var.pdispVal = tmp;
	
	worksheet=worksheets.Add(var,vtOptional,COleVariant(long(1)),vtOptional);

	tmp.ReleaseDispatch();
}

void SimpleExcel::RemoveSheet(long iSheet)
{

	if ((iSheet<1)||(iSheet>(long)worksheets.GetCount()))
	{
		return ;
	}
	worksheets=workbook.GetWorksheets();
	
	worksheet= worksheets.GetItem(COleVariant(iSheet));

	worksheet.Delete();

	worksheet.ReleaseDispatch();
}

}