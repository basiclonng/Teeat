// excelautoDlg.h : header file
//

#if !defined(AFX_EXCELAUTODLG_H__C0D1BC4A_5045_400E_9D8B_A680ACF607FF__INCLUDED_)
#define AFX_EXCELAUTODLG_H__C0D1BC4A_5045_400E_9D8B_A680ACF607FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "AdoHelp.h"
#include "SimpleExcel.h"
#include <comdef.h>
using namespace ADOCG;
/////////////////////////////////////////////////////////////////////////////
// CExcelautoDlg dialog

class CExcelautoDlg : public CDialog
{
// Construction
public:
	BOOL AdoRecordToExcelSheet(_RecordsetPtr tmpm_pRecordset,XEXCEL::SimpleExcel * xls);
	BOOL AdoAccessToExcel(XEXCEL::SimpleExcel * xls,LPCTSTR access);
	CExcelautoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CExcelautoDlg)
	enum { IDD = IDD_EXCELAUTO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExcelautoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CExcelautoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXCELAUTODLG_H__C0D1BC4A_5045_400E_9D8B_A680ACF607FF__INCLUDED_)
