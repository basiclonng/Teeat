// excelauto.h : main header file for the EXCELAUTO application
//

#if !defined(AFX_EXCELAUTO_H__9E806EDB_8BDA_4855_B0A4_438266CA06AE__INCLUDED_)
#define AFX_EXCELAUTO_H__9E806EDB_8BDA_4855_B0A4_438266CA06AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CExcelautoApp:
// See excelauto.cpp for the implementation of this class
//

class CExcelautoApp : public CWinApp
{
public:
	CExcelautoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExcelautoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CExcelautoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXCELAUTO_H__9E806EDB_8BDA_4855_B0A4_438266CA06AE__INCLUDED_)
