// excelautoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "excelauto.h"
#include "excelautoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


using namespace ADOCG;
BOOL GetAllFields(_RecordsetPtr m_pRecordset,CStringArray & fieldsarray)
{
	if (m_pRecordset)
	{
		if (m_pRecordset->State)
		{
			try
			{
				HRESULT   hr;		
				ADOCG::Fields *  fields = NULL;		
				hr = m_pRecordset->get_Fields (&fields);
				long ColCount;		
				if(SUCCEEDED(hr)) 		
					fields->get_Count(&ColCount);		
				for(long i=0;i<ColCount;i++)
				{	
					ADOCG::Field *   field = NULL;	
					field = fields->GetItem((_variant_t)(i));		
					fieldsarray.Add(CString((LPCTSTR)field->GetName()));
					
				}	
				if(SUCCEEDED(hr))		
					fields->Release();
				
			}
			
			catch(_com_error e)
			{ 		
				::MessageBox(NULL,e.ErrorMessage(),"����",MB_OK);
				return FALSE; 
			}	
			return TRUE;
			
		}
	}
	return FALSE;
				
	
}
BOOL GetAllTables(LPCTSTR databasefile,CStringArray & dbtables)
{
	_ConnectionPtr m_pConnection; 	
	_RecordsetPtr m_pRecordset; 	
	HRESULT hr; 	
	try 		
	{  
		CoInitialize(NULL);
		hr = m_pConnection.CreateInstance(__uuidof(Connection)); 
		hr =m_pRecordset.CreateInstance(__uuidof(Recordset));
		
		if(SUCCEEDED(hr)) 			
		{   
			CString strconnection; 			
			strconnection.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=%s",databasefile); 			
			hr = m_pConnection->Open((_bstr_t)strconnection,"","",adModeUnknown); 			
			m_pRecordset = m_pConnection->OpenSchema(adSchemaTables);  			
			while(!(m_pRecordset->adoEOF))   				
			{  				
				_bstr_t table_name = m_pRecordset->Fields->GetItem("TABLE_NAME")->Value;				
				_bstr_t table_type = m_pRecordset->Fields->GetItem("TABLE_TYPE")->Value;								
				if ( strcmp(((LPCSTR)table_type),"TABLE")==0){
					CString table;
					table.Format("%s",(LPCSTR)table_name);  	
					dbtables.Add(table);					
					
				}     
				m_pRecordset->MoveNext();    				
			}   			
			m_pRecordset->Close();  			
		}  		
		m_pConnection->Close(); 
		m_pRecordset.Release();
		m_pConnection.Release();
		CoUninitialize();
	}catch(_com_error e)
	{ 		
		::MessageBox(NULL,e.ErrorMessage(),"����",MB_OK);
		return FALSE; 
	}
	return TRUE;
}
CString VariantToString(VARIANT var)
{
	CString strValue;
	
	_variant_t var_t;
	
	_bstr_t bstr_t;
	
	time_t cur_time;
	
	CTime time_value;
	
	COleCurrency var_currency;
	
	switch(var.vt)
		
	{
		
	case VT_EMPTY:
		
	case VT_NULL:strValue=_T("");break;
		
	case VT_UI1:strValue.Format("%d",var.bVal);break;
		
	case VT_I2:strValue.Format("%d",var.iVal);break;
		
	case VT_I4:strValue.Format("%d",var.lVal);break;
		
	case VT_R4:strValue.Format("%f",var.fltVal);break;
		
	case VT_R8:strValue.Format("%f",var.dblVal);break;
		
	case VT_CY:
		
		var_currency=var;
		
		strValue=var_currency.Format(0);break;
		
	case VT_BSTR:
		
		var_t =var;
		
		bstr_t=var_t;
		
		strValue.Format("%s",(const char *)bstr_t);break;
		
	case VT_DATE:
		
		cur_time=var.date;
		
		time_value=cur_time;
		
		strValue.Format("%A,%B,%d,%Y");break;
		
	case VT_BOOL:strValue.Format("%d",var.boolVal);break;
		
	default:strValue=_T("");break;
		
	}
	return strValue;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExcelautoDlg dialog

CExcelautoDlg::CExcelautoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CExcelautoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExcelautoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CExcelautoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExcelautoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CExcelautoDlg, CDialog)
	//{{AFX_MSG_MAP(CExcelautoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExcelautoDlg message handlers

BOOL CExcelautoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CExcelautoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CExcelautoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CExcelautoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CExcelautoDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	try
	{
		
		XEXCEL::SimpleExcel xls;
		xls.CreateApp();

		TCHAR path[MAX_PATH];
		GetCurrentDirectory(MAX_PATH,path);
		CString xlsname;
		xlsname=path;
		xlsname+="\\test.xls";


		xls.Open(xlsname);
		//xls.CreateWorkbook();
		
		xls.SetCellString(1,1,"hello world");          //���õ�Ԫ������Ϊ�ִ� 
		
		xls.SetSheetCellString(2,1,1,"New");           //����ָ�������ĵ�Ԫ������Ϊ�ִ�

		xls.SetCellValue(2,2,COleVariant(COleDateTime::GetCurrentTime()));    //���õ�Ԫ�����ݣ������Ǳ�������

		xls.SetCellColor(2,2,0xFF0000);                //���õ�Ԫ����ɫ           
	//	xls.MergeCell(2,1,3,1);//�ӵڶ��е�һ�кϲ��������е�һ��
		xls.MakeAutoFit();                             //ʹ��Ԫ���Զ�����


		CString pname;
		pname=path;
		pname+="\\english2.mdb";
		//AdoAccessToExcel(&xls,pname);                 //��access���ݿ��е����б�������excel��
		//xls.MakeAutoFit();

		xls.SetSheetName(1,"����һ");

		//xls.RemoveSheet(3);


		xls.SheetSelect(1);


		

//		xls.InsertSheeta(1);                             //�ڵ�һ�����������һ������

//		xls.InsertSheetb(1);                             //�ڵ�һ������ǰ����һ������

//		xls.MoveSheeta(4,2);                             //�ƶ��ڶ������������ĸ�������

//		xls.MoveSheetb(1,2);                             //�ƶ��ڶ�����������һ������ǰ

//		xls.AddSheet();                                  //�����һ������������һ������

//		xls.AddSheet(15);                                 //�����һ������������ʮ�������

		xls.Show(TRUE);


		xls.ReleaseControl();                            //����Ȩ�����û�

		//xls.CloseWorkbook();
		//xls.CreateWorkbook();
		//xls.SetSheetCellValue(1,1,1,COleVariant("hello world !"));
		//xls.MakeAutoFit();
		//xls.Save();
		//xls.CloseApp();

		//xls.Save("C:\\test.xls");
		//xls.Close();
	}
	catch (_com_error & e)
	{
		MessageBox(e.Description());
		
	}



}

BOOL CExcelautoDlg::AdoAccessToExcel(XEXCEL::SimpleExcel *xls, LPCTSTR access)
{
	CoInitialize(NULL);
	_ConnectionPtr m_pConnection2;
	CString		strConnection;	//�����ַ���
	m_pConnection2.CreateInstance(__uuidof(Connection));
	strConnection.Format(_T("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=%s;Persist Security Info=False"),access);
	//		MessageBox(strConnection);
	HRESULT		hResult=m_pConnection2->Open(strConnection.GetBuffer(0) ,"" ,"" ,adModeUnknown);
	strConnection.ReleaseBuffer();		
	if(!SUCCEEDED(hResult))
		return  FALSE ;				//����ʧ��
	try
	{
		CTime start=CTime::GetCurrentTime();	
		CStringArray tablenames;
		GetAllTables(access,tablenames);
		m_pConnection2->BeginTrans();
		_RecordsetPtr tmpm_pRecordset; 
		tmpm_pRecordset.CreateInstance(__uuidof(Recordset));
		CString strSql;
		for (int i=0;i<tablenames.GetSize();i++)
		{	
			strSql.Format("select * from %s",tablenames.GetAt(i));			
			tmpm_pRecordset->Open((_bstr_t)strSql,_variant_t((IDispatch*)m_pConnection2,true),adOpenStatic,adLockOptimistic,adCmdText);
			xls->SheetSelect(long(i+1));
			AdoRecordToExcelSheet(tmpm_pRecordset,xls);
			tmpm_pRecordset->Close();		
		}
		tmpm_pRecordset.Release();
		m_pConnection2->CommitTrans();
		
		m_pConnection2->Close();
		m_pConnection2.Release();
		
		
		CTime end=CTime::GetCurrentTime();
		CTimeSpan tmr3=end-start;
		LONGLONG longsum = tmr3.GetTotalSeconds();
		CString msg;
		msg.Format("�ķ�ʱ��:%d��",longsum);
		MessageBox(msg);
		
	}
	catch (_com_error & e)
	{
		m_pConnection2->RollbackTrans();
		MessageBox(e.Description());
		return FALSE;
	}
	CoUninitialize();
	return TRUE;
}

BOOL CExcelautoDlg::AdoRecordToExcelSheet(_RecordsetPtr tmpm_pRecordset, XEXCEL::SimpleExcel *xls)
{

		try
		{
			CStringArray fieldnames;
			GetAllFields(tmpm_pRecordset,fieldnames);			
			int count=tmpm_pRecordset->GetRecordCount();
			for (int j=0;j<fieldnames.GetSize();j++)
			{
				xls->SetCellString(1,j+1,fieldnames.GetAt(j));
			}
			tmpm_pRecordset->MoveFirst();
			int row=2;
			while(!tmpm_pRecordset->adoEOF)
			{
				for (int j=0;j<fieldnames.GetSize();j++)
				{
					_variant_t vtvalue;
					vtvalue=tmpm_pRecordset->GetCollect((_bstr_t)fieldnames.GetAt(j));
					CString str=VariantToString(vtvalue);
					xls->SetCellString(row,j+1,str)	;				
				}				
				tmpm_pRecordset->MoveNext();
				row++;
			}	
			
		}
		catch (_com_error & e)
		{	
			MessageBox(e.Description());
			return FALSE;
		}
		return TRUE;

}
