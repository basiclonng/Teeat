// AdoHelp.h: interface for the CAdoHelp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADOHELP_H__6251EA94_2C03_45D4_976D_F1A5EB7BE7EF__INCLUDED_)
#define AFX_ADOHELP_H__6251EA94_2C03_45D4_976D_F1A5EB7BE7EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAdoHelp  
{
public:
	CAdoHelp();
	virtual ~CAdoHelp();

};

    
#endif // !defined(AFX_ADOHELP_H__6251EA94_2C03_45D4_976D_F1A5EB7BE7EF__INCLUDED_)
