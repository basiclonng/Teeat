//   ����VC6����OFFICE2003ϵ��Դ���е�һ����
//   ʵ�ֶ�EXCEL2003�Ŀ��������
//   ���������ɿ�����ʹ�ñ�Դ��
//   
//    

// SimpleExcel.h: interface for the SimpleExcel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLEEXCEL_H__1B066D7F_4435_400C_BD6E_0C77EB99FA29__INCLUDED_)
#define AFX_SIMPLEEXCEL_H__1B066D7F_4435_400C_BD6E_0C77EB99FA29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "excel.h"
namespace XEXCEL
{


//Ϊ��ֹ������ͻ��ʹ���������ռ�

class SimpleExcel  
{
private:
	_Application excelapp;
	Worksheets worksheets;
	Workbooks workbooks;
	_Worksheet worksheet;
	_Workbook workbook;
	COleVariant vtOptional;
	Range range;
	COleVariant vTrue;
	COleVariant	vFalse;
	Range cols;

public:

	void RemoveSheet(long iSheet);
	void InsertSheetb(long ibefore);
	void MoveSheetb(long ibefore,long isheet);
	void MoveSheeta(long iafter,long isheet);
	void InsertSheeta(long after);
	void SetSheetName(long sheet,LPCTSTR sheetname);
	void AddSheet(long count);
	void AddSheet();
	void SetCellColor(long irow,long icol,COLORREF color);
	void MergeCell(long irows,long icols,long irowe,long icole);
	void SheetSelect(long isheet);
	void SetSheetCellValue(long isheet,long irow,long icol,VARIANT & vt);
	void CloseWorkbook();
	void Save();
	void MakeAutoFit();
	void SetCellValue(long irow,long icol,VARIANT & vt);
	void Open(LPCTSTR name);
	void ReleaseControl();
	void CreateExcel();
	void CloseAppSave(LPCTSTR name);
	void CloseApp();
	void SaveAs(LPCTSTR name);
	void SetSheetCellString(long isheet,long irow,long icol,LPCTSTR value);
	void SetCellString(long irow,long icol,LPCTSTR value);
	void Show(BOOL bNewValue);
	void CreateWorkbook();
	BOOL CreateApp();
	SimpleExcel();
	virtual ~SimpleExcel();

};
}
#endif // !defined(AFX_SIMPLEEXCEL_H__1B066D7F_4435_400C_BD6E_0C77EB99FA29__INCLUDED_)
