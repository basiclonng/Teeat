// AdoHelp.cpp: implementation of the CAdoHelp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "excelauto.h"
#include "AdoHelp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAdoHelp::CAdoHelp()
{

}

CAdoHelp::~CAdoHelp()
{

}
